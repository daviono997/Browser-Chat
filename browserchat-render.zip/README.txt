UPLOAD THIS PROJECT TO RENDER

1. Create a new Web Service on Render
2. Upload or connect this project repo
3. Settings:

Build Command:
npm install

Start Command:
npm start

Render will host the browser and chat server together.
Open the provided URL and the browser + chat will load.